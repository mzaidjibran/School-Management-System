import dotenv from "dotenv";
dotenv.config();
import express from "express";
import connectDB from "./config/config.js";
import cors from "cors";
import path from "path";
import { fileURLToPath } from "url";

import Student_Route from "./routers/Student_Route.js";
import Attendence_Route from "./routers/Attendence_Route.js";
import Fee_Route from "./routers/Fee_Route.js";
import Auth_Route from "./routers/Auth_Route.js";
import Class_Route from "./routers/Class_Route.js";
import teacherRoutes from "./routers/Teacher_Route.js";
import examRoutes from "./routers/Exam_Routes.js";
import noticeRoutes from "./routers/Notice_Routes.js";
import subjectRoutes from "./routers/Subject_routes.js";
import timetableRoutes from "./routers/TimeTable_Routes.js";
import branchRoutes from "./routers/Branch_Route.js";
import payrollRoutes from "./routers/Payroll_Route.js";
import whatsappRoutes from "./routers/whatsapp_routes.js";
import notificationRoutes from "./routers/Notification_Route.js";

const app = express();
const port = process.env.PORT || 5000;

connectDB();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

app.use(express.json());
const allowedOrigins = [
  "https://nullstacksloution.online",
  "http://nullstacksloution.online",
  "https://www.nullstacksloution.online",
  "http://www.nullstacksloution.online",
  "https://api.nullstacksloution.online",
  "http://api.nullstacksloution.online",
  ...(process.env.CLIENT_URL ? process.env.CLIENT_URL.split(",").map((s) => s.trim()) : []),
  ...(process.env.ALLOWED_ORIGINS ? process.env.ALLOWED_ORIGINS.split(",").map((s) => s.trim()) : []),
];

app.use(
  cors({
    origin: function (origin, callback) {
      if (!origin) return callback(null, true);

      if (
        origin.startsWith("http://localhost") ||
        origin.startsWith("http://127.0.0.1") ||
        allowedOrigins.includes(origin) ||
        origin.includes("nullstacksloution.online")
      ) {
        return callback(null, true);
      }
      callback(new Error("Not allowed by CORS"));
    },
    credentials: true,
  }),
);

app.use("/image", express.static(path.join(__dirname, "public/image")));

app.get("/", (req, res) => {
  res.send("Backend is running...");
});

app.use("/api/auth", Auth_Route);
app.use("/api/students", Student_Route);
app.use("/api/attendance", Attendence_Route);
app.use("/api/fee", Fee_Route);
app.use("/api/classes", Class_Route);
app.use("/api/teachers", teacherRoutes);
app.use("/api/exams", examRoutes);
app.use("/api/notices", noticeRoutes);
app.use("/api/subjects", subjectRoutes);
app.use("/api/timetable", timetableRoutes);
app.use("/api/branches", branchRoutes);
app.use("/api/payroll", payrollRoutes);
app.use("/api/whatsapp", whatsappRoutes);
app.use("/api/notifications", notificationRoutes);

app.get("/api/test", (req, res) => {
  res.json({ message: "API working successfully" });
});

app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: "Something went wrong!" });
});

app.use((req, res) => {
  res.status(404).json({ error: "Route not found" });
});

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
