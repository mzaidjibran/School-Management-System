import { Fee } from "../models/Fee_Model.js";
import { createNotificationHelper } from "./Notification_Controller.js";

// ─── Helper: Receipt Number Generate Karo ────────────────────────
function generateReceiptNumber() {
  const timestamp = Date.now().toString().slice(-6);
  const random = Math.floor(Math.random() * 1000)
    .toString()
    .padStart(3, "0");
  return `RCP-${timestamp}-${random}`;
}

// ─── Create Fee Record ────────────────────────────────────────────
export const createFee = async (request, response) => {
  try {
    const ownerId = request.user && request.user.role === "teacher" ? request.user.createdBy : request.userId;
    request.body.createdBy = ownerId;
    if (request.headers["x-branch-id"]) request.body.branch = request.headers["x-branch-id"];
    if (request.user && request.user.role === "teacher") {
      request.body.schoolSection = request.user.gender === "female" ? "girls" : "boys";
    } else if (request.headers["x-section"]) {
      request.body.schoolSection = request.headers["x-section"];
    }
    const fee = await Fee.create(request.body);
    await createNotificationHelper(
      "Fee Invoice Created",
      `New Fee Invoice of Rs. ${fee.amount} generated for student.`,
      "fee"
    );

    response.status(201).json({
      success: true,
      error: false,
      message: "Fee record created successfully",
      data: fee,
    });
  } catch (error) {
    if (error.code === 11000) {
      return response.status(409).json({
        success: false,
        error: true,
        message: "Is mahine ki yeh fee already create ho chuki hai",
      });
    }
    response.status(500).json({
      success: false,
      error: true,
      message: error.message,
    });
  }
};

// ─── Get All Fees Of A Student ────────────────────────────────────
export const getStudentFees = async (request, response) => {
  try {
    const { studentId } = request.params;
    const { status, year } = request.query;

    const ownerId = request.user && request.user.role === "teacher" ? request.user.createdBy : request.userId;
    const filter = { student: studentId, createdBy: ownerId };
    if (status) filter.status = status;
    if (year) filter.year = Number(year);
    if (request.headers["x-branch-id"]) filter.branch = request.headers["x-branch-id"];
    if (request.user && request.user.role === "teacher") {
      filter.schoolSection = request.user.gender === "female" ? "girls" : "boys";
    } else if (request.headers["x-section"]) {
      filter.schoolSection = request.headers["x-section"];
    }

    const fees = await Fee.find(filter).sort({ year: -1, month: -1 });

    const totalAmount = fees.reduce((sum, f) => sum + f.amount, 0);
    const totalPaid = fees.reduce((sum, f) => sum + f.paidAmount, 0);
    const totalDue = totalAmount - totalPaid;

    response.status(200).json({
      success: true,
      error: false,
      message: "Fees fetched successfully",
      data: fees,
      summary: { totalAmount, totalPaid, totalDue },
    });
  } catch (error) {
    response.status(500).json({
      success: false,
      error: true,
      message: error.message,
    });
  }
};

// ─── Get Pending Fees ─────────────────────────────────────────────
export const getPendingFees = async (request, response) => {
  try {
    const ownerId = request.user && request.user.role === "teacher" ? request.user.createdBy : request.userId;
    const filter = {
      createdBy: ownerId,
      status: { $in: ["pending", "partial", "overdue"] },
    };
    if (request.headers["x-branch-id"]) filter.branch = request.headers["x-branch-id"];
    if (request.user && request.user.role === "teacher") {
      filter.schoolSection = request.user.gender === "female" ? "girls" : "boys";
    } else if (request.headers["x-section"]) {
      filter.schoolSection = request.headers["x-section"];
    }

    const fees = await Fee.find(filter)
      .populate("student", "firstName lastName rollNumber")
      .sort({ dueDate: 1 });

    response.status(200).json({
      success: true,
      error: false,
      message: "Pending fees fetched successfully",
      data: fees,
      total: fees.length,
    });
  } catch (error) {
    response.status(500).json({
      success: false,
      error: true,
      message: error.message,
    });
  }
};

// ─── Get All Fee Records ──────────────────────────────────────────
export const getAllFees = async (request, response) => {
  try {
    const { status, month, year } = request.query;

    const ownerId = request.user && request.user.role === "teacher" ? request.user.createdBy : request.userId;
    const filter = { createdBy: ownerId };
    if (status) filter.status = status;
    if (month) filter.month = Number(month);
    if (year) filter.year = Number(year);
    if (request.headers["x-branch-id"]) filter.branch = request.headers["x-branch-id"];
    if (request.user && request.user.role === "teacher") {
      filter.schoolSection = request.user.gender === "female" ? "girls" : "boys";
    } else if (request.headers["x-section"]) {
      filter.schoolSection = request.headers["x-section"];
    }

    const fees = await Fee.find(filter)
      .populate({
        path: "student",
        select: "firstName lastName rollNumber currentClass section",
        populate: {
          path: "currentClass",
          select: "name",
        },
      })
      .sort({ year: -1, month: -1, dueDate: 1 });

    response.status(200).json({
      success: true,
      error: false,
      message: "All fees fetched successfully",
      data: fees,
      total: fees.length,
    });
  } catch (error) {
    response.status(500).json({
      success: false,
      error: true,
      message: error.message,
    });
  }
};

// ─── Pay Fee ─────────────────────────────────────────────────────
export const payFee = async (request, response) => {
  try {
    const { id } = request.params;
    const { payingAmount, paymentMethod } = request.body;

    const ownerId = request.user && request.user.role === "teacher" ? request.user.createdBy : request.userId;
    const query = { _id: id, createdBy: ownerId };
    if (request.headers["x-branch-id"]) query.branch = request.headers["x-branch-id"];
    if (request.user && request.user.role === "teacher") {
      query.schoolSection = request.user.gender === "female" ? "girls" : "boys";
    } else if (request.headers["x-section"]) {
      query.schoolSection = request.headers["x-section"];
    }

    const fee = await Fee.findOne(query);
    if (!fee) {
      return response.status(404).json({
        success: false,
        error: true,
        message: "Fee record not found",
      });
    }

    if (fee.status === "paid") {
      return response.status(400).json({
        success: false,
        error: true,
        message: "Yeh fee already pay ho chuki hai",
      });
    }

    fee.paidAmount += Number(payingAmount);
    fee.paymentMethod = paymentMethod;
    fee.paidDate = request.body.paidDate ? new Date(request.body.paidDate) : new Date();

    if (fee.paidAmount >= fee.amount) {
      fee.status = "paid";
      fee.paidAmount = fee.amount;
      fee.receiptNumber = generateReceiptNumber();
    } else {
      fee.status = "partial";
    }

    await fee.save();
    await createNotificationHelper(
      "Fee Payment Received",
      `Payment of Rs. ${payingAmount} received for Student Fee (Status: ${fee.status.toUpperCase()}).`,
      "fee"
    );

    response.status(200).json({
      success: true,
      error: false,
      message:
        fee.status === "paid"
          ? "Fee fully paid! Receipt generated."
          : "Partial payment recorded",
      data: fee,
    });
  } catch (error) {
    response.status(500).json({
      success: false,
      error: true,
      message: error.message,
    });
  }
};

// ─── Update Fee Record ────────────────────────────────────────────
export const updateFee = async (request, response) => {
  try {
    const ownerId = request.user && request.user.role === "teacher" ? request.user.createdBy : request.userId;
    const query = { _id: request.params.id, createdBy: ownerId };
    if (request.headers["x-branch-id"]) query.branch = request.headers["x-branch-id"];
    if (request.user && request.user.role === "teacher") {
      query.schoolSection = request.user.gender === "female" ? "girls" : "boys";
    } else if (request.headers["x-section"]) {
      query.schoolSection = request.headers["x-section"];
    }

    const updated = await Fee.findOneAndUpdate(
      query,
      request.body,
      { new: true, runValidators: true }
    );

    if (!updated) {
      return response.status(404).json({
        success: false,
        error: true,
        message: "Fee record not found",
      });
    }

    response.status(200).json({
      success: true,
      error: false,
      message: "Fee updated successfully",
      data: updated,
    });
  } catch (error) {
    response.status(500).json({
      success: false,
      error: true,
      message: error.message,
    });
  }
};

// ─── Delete Fee Record ────────────────────────────────────────────
export const deleteFee = async (request, response) => {
  try {
    const ownerId = request.user && request.user.role === "teacher" ? request.user.createdBy : request.userId;
    const query = { _id: request.params.id, createdBy: ownerId };
    if (request.headers["x-branch-id"]) query.branch = request.headers["x-branch-id"];
    if (request.user && request.user.role === "teacher") {
      query.schoolSection = request.user.gender === "female" ? "girls" : "boys";
    } else if (request.headers["x-section"]) {
      query.schoolSection = request.headers["x-section"];
    }

    const deleted = await Fee.findOneAndDelete(query);

    if (!deleted) {
      return response.status(404).json({
        success: false,
        error: true,
        message: "Fee record not found",
      });
    }

    response.status(200).json({
      success: true,
      error: false,
      message: "Fee record deleted successfully",
      data: deleted,
    });
  } catch (error) {
    response.status(500).json({
      success: false,
      error: true,
      message: error.message,
    });
  }
};